PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":462,"bgColor":"#ffffff","bgImage":"images/eval9.png","bgSize":"785px 496px","bgRepeat":"no-repeat"}
,
"button43255":{"x":729,"y":12,"w":44.000000,"h":44.000000,"stylemods":[{"sel":"div.button43255Text","decl":" { position:fixed; left:2px; top:2px; width:39px; height:39px;}"},{"sel":"span.button43255Text","decl":" { display:table-cell; position:relative; width:39px; height:39px; vertical-align:middle; text-align:center; line-height:9px; font-size:9px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAAAAALjUAB5sAAHaZvU3AAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAAAAALjUAB5sAAHaZvU3AAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAAAAALjUAB5sAAHaZvU3AAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAAAAALjUAB5sAAHaZvU3AAAAAElFTkSuQmCC"  ,"fd": "images/tombol_home.png" ,"fdO": "images/tombol_home.png" ,"fdD": "images/tombol_home.png" ,"fdDi": "images/tombol_home.png" ,"p": "M 0.000000 0.000000 L 43.000000 0.000000 L 43.000000 43.000000 L 0.000000 43.000000 L 0.000000 0.000000 z"}
,
"button29649":{"x":664,"y":407,"w":56.000000,"h":56.000000,"stylemods":[{"sel":"div.button29649Text","decl":" { position:fixed; left:2px; top:2px; width:51px; height:51px;}"},{"sel":"span.button29649Text","decl":" { display:table-cell; position:relative; width:51px; height:51px; vertical-align:middle; text-align:center; line-height:9px; font-size:9px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAjSURBVGhD7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAABwqQYxOAAB1daAAAAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAjSURBVGhD7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAABwqQYxOAAB1daAAAAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAjSURBVGhD7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAABwqQYxOAAB1daAAAAAAABJRU5ErkJggg==" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAjSURBVGhD7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAABwqQYxOAAB1daAAAAAAABJRU5ErkJggg=="  ,"fd": "images/tombol_next.png" ,"fdO": "images/tombol_next.png" ,"fdD": "images/tombol_next.png" ,"fdDi": "images/tombol_next.png" ,"p": "M 0.000000 0.000000 L 55.000000 0.000000 L 55.000000 55.000000 L 0.000000 55.000000 L 0.000000 0.000000 z"}
,
"other28053":{"x":637,"y":34,"w":138,"h":70,"fsize":24,"bOffBottom":0}
,
"text20172":{"x":-16,"y":118,"w":11,"h":23,"txtscale":100,"bOffBottom":0}
,
"image20173":{"x":-17,"y":151,"w":12,"h":6,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20175":{"x":342,"y":299,"fsize":39,"bOffBottom":0}
,
"image20176":{"x":-17,"y":161,"w":12,"h":6,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20178":{"x":342,"y":317,"fsize":39,"bOffBottom":0}
,
"image20179":{"x":-17,"y":172,"w":12,"h":6,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20181":{"x":342,"y":338,"fsize":39,"bOffBottom":0}
,
"image20182":{"x":-17,"y":182,"w":12,"h":6,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20184":{"x":342,"y":357,"fsize":39,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/eval9.png']
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#ffffff","bgImage":"images/eval9.png","bgSize":"480px 304px","bgRepeat":"no-repeat"}
,
"button43255":{"x":446,"y":19,"w":28.000000,"h":28.000000,"stylemods":[{"sel":"div.button43255Text","decl":" { position:fixed; left:2px; top:2px; width:23px; height:23px;}"},{"sel":"span.button43255Text","decl":" { display:table-cell; position:relative; width:23px; height:23px; vertical-align:middle; text-align:center; line-height:5px; font-size:5px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAaSURBVEhL7cExAQAAAMKg9U9tCF8gAACAWw0MXAAB3XeTugAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAaSURBVEhL7cExAQAAAMKg9U9tCF8gAACAWw0MXAAB3XeTugAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAaSURBVEhL7cExAQAAAMKg9U9tCF8gAACAWw0MXAAB3XeTugAAAABJRU5ErkJggg==" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAaSURBVEhL7cExAQAAAMKg9U9tCF8gAACAWw0MXAAB3XeTugAAAABJRU5ErkJggg=="  ,"fd": "images/tombol_home.png" ,"fdO": "images/tombol_home.png" ,"fdD": "images/tombol_home.png" ,"fdDi": "images/tombol_home.png" ,"p": "M 0.000000 0.000000 L 27.000000 0.000000 L 27.000000 27.000000 L 0.000000 27.000000 L 0.000000 0.000000 z"}
,
"button29649":{"x":406,"y":656,"w":35.000000,"h":35.000000,"stylemods":[{"sel":"div.button29649Text","decl":" { position:fixed; left:2px; top:2px; width:30px; height:30px;}"},{"sel":"span.button29649Text","decl":" { display:table-cell; position:relative; width:30px; height:30px; vertical-align:middle; text-align:center; line-height:5px; font-size:5px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACMAAAAjCAYAAAAe2bNZAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cGBAAAAAMOg+VPf4ARVAAAAAMBXAxNHAAHAf9TiAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACMAAAAjCAYAAAAe2bNZAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cGBAAAAAMOg+VPf4ARVAAAAAMBXAxNHAAHAf9TiAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACMAAAAjCAYAAAAe2bNZAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cGBAAAAAMOg+VPf4ARVAAAAAMBXAxNHAAHAf9TiAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACMAAAAjCAYAAAAe2bNZAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cGBAAAAAMOg+VPf4ARVAAAAAMBXAxNHAAHAf9TiAAAAAElFTkSuQmCC"  ,"fd": "images/tombol_next.png" ,"fdO": "images/tombol_next.png" ,"fdD": "images/tombol_next.png" ,"fdDi": "images/tombol_next.png" ,"p": "M 0.000000 0.000000 L 34.000000 0.000000 L 34.000000 34.000000 L 0.000000 34.000000 L 0.000000 0.000000 z"}
,
"other28053":{"x":389,"y":54,"w":138,"h":70,"fsize":24,"bOffBottom":0}
,
"text20172":{"x":53,"y":75,"w":373,"h":37,"txtscale":100,"bOffBottom":0}
,
"image20173":{"x":80,"y":120,"w":19,"h":9,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20175":{"x":50,"y":114,"fsize":39,"bOffBottom":0}
,
"image20176":{"x":80,"y":137,"w":19,"h":9,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20178":{"x":50,"y":131,"fsize":39,"bOffBottom":0}
,
"image20179":{"x":80,"y":154,"w":19,"h":9,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20181":{"x":50,"y":148,"fsize":39,"bOffBottom":0}
,
"image20182":{"x":80,"y":171,"w":19,"h":9,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20184":{"x":50,"y":165,"fsize":39,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/eval9.png']
}}
