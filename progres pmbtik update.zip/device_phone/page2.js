PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":493,"bgColor":"#ffffff","bgImage":"images/start_bg.png","bgSize":"785px 496px","bgRepeat":"no-repeat"}
,
"button2124":{"x":168,"y":280,"w":180.000000,"h":51.000000,"stylemods":[{"sel":"div.button2124Text","decl":" { position:fixed; left:2px; top:2px; width:175px; height:46px;}"},{"sel":"span.button2124Text","decl":" { display:table-cell; position:relative; width:175px; height:46px; vertical-align:middle; text-align:center; line-height:9px; font-size:9px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAAzCAYAAAA+eCJSAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA7SURBVHhe7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4UAOPowABXdpdowAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAAzCAYAAAA+eCJSAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA7SURBVHhe7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4UAOPowABXdpdowAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAAzCAYAAAA+eCJSAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA7SURBVHhe7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4UAOPowABXdpdowAAAABJRU5ErkJggg==" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAAzCAYAAAA+eCJSAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA7SURBVHhe7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4UAOPowABXdpdowAAAABJRU5ErkJggg=="  ,"fd": "images/start.png" ,"fdO": "images/start.png" ,"fdD": "images/start.png" ,"fdDi": "images/start.png" ,"p": "M 0.000000 0.000000 L 179.000000 0.000000 L 179.000000 50.000000 L 0.000000 50.000000 L 0.000000 0.000000 z"}
,
"image35949":{"x":0,"y":-3,"w":785,"h":496,"bOffBottom":0,"i":"images/halaman_start.png"}
,
"text21091":{"x":261,"y":156,"w":93,"h":44,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/start_bg.png']
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#ffffff","bgImage":"images/start_bg.png","bgSize":"480px 304px","bgRepeat":"no-repeat"}
,
"button2124":{"x":102,"y":452,"w":111.000000,"h":32.000000,"stylemods":[{"sel":"div.button2124Text","decl":" { position:fixed; left:2px; top:2px; width:106px; height:27px;}"},{"sel":"span.button2124Text","decl":" { display:table-cell; position:relative; width:106px; height:27px; vertical-align:middle; text-align:center; line-height:5px; font-size:5px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAG8AAAAgCAYAAAAcyybZAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAlSURBVGhD7cExAQAAAMKg9U9tBn8gAAAAAAAAAAAAAAAAAOBUAzegAAG/XwqjAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAG8AAAAgCAYAAAAcyybZAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAlSURBVGhD7cExAQAAAMKg9U9tBn8gAAAAAAAAAAAAAAAAAOBUAzegAAG/XwqjAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAG8AAAAgCAYAAAAcyybZAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAlSURBVGhD7cExAQAAAMKg9U9tBn8gAAAAAAAAAAAAAAAAAOBUAzegAAG/XwqjAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAG8AAAAgCAYAAAAcyybZAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAlSURBVGhD7cExAQAAAMKg9U9tBn8gAAAAAAAAAAAAAAAAAOBUAzegAAG/XwqjAAAAAElFTkSuQmCC"  ,"fd": "images/start.png" ,"fdO": "images/start.png" ,"fdD": "images/start.png" ,"fdDi": "images/start.png" ,"p": "M 0.000000 0.000000 L 110.000000 0.000000 L 110.000000 31.000000 L 0.000000 31.000000 L 0.000000 0.000000 z"}
,
"image35949":{"x":0,"y":-5,"w":480,"h":304,"bOffBottom":0,"i":"images/halaman_start.png"}
,
"text21091":{"x":159,"y":251,"w":57,"h":44,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/start_bg.png']
}}
