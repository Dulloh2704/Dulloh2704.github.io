PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":474,"bgColor":"#ffffff","bgImage":"images/login_bg_1_.png","bgSize":"785px 496px","bgRepeat":"no-repeat"}
,
"button20480":{"x":324,"y":431,"w":136.000000,"h":44.000000,"stylemods":[{"sel":"div.button20480Text","decl":" { position:fixed; left:2px; top:2px; width:131px; height:39px;}"},{"sel":"span.button20480Text","decl":" { display:table-cell; position:relative; width:131px; height:39px; vertical-align:middle; text-align:center; line-height:9px; font-size:9px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIgAAAAsCAYAAAC+N/CqAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAtSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHdqXawAAcKBqVAAAAAASUVORK5CYII=" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIgAAAAsCAYAAAC+N/CqAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAtSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHdqXawAAcKBqVAAAAAASUVORK5CYII=" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIgAAAAsCAYAAAC+N/CqAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAtSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHdqXawAAcKBqVAAAAAASUVORK5CYII=" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIgAAAAsCAYAAAC+N/CqAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAtSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHdqXawAAcKBqVAAAAAASUVORK5CYII="  ,"fd": "images/tombol.png" ,"fdO": "images/tombol.png" ,"fdD": "images/tombol.png" ,"fdDi": "images/tombol.png" ,"p": "M 0.000000 0.000000 L 135.000000 0.000000 L 135.000000 43.000000 L 0.000000 43.000000 L 0.000000 0.000000 z"}
,
"text21064":{"x":-29,"y":131,"w":24,"h":88,"txtscale":100,"bOffBottom":0}
,
"entry21065":{"x":174,"y":366,"w":450,"h":41,"fsize":39,"bOffBottom":0}
,
"text21011":{"x":-21,"y":135,"w":16,"h":88,"txtscale":100,"bOffBottom":0}
,
"entry21012":{"x":259,"y":270,"w":450,"h":45,"fsize":39,"bOffBottom":0}
,
"text21037":{"x":-20,"y":135,"w":15,"h":44,"txtscale":100,"bOffBottom":0}
,
"entry21038":{"x":277,"y":318,"w":450,"h":43,"fsize":39,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/login_bg_1_.png']
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#ffffff","bgImage":"images/login_bg_1_.png","bgSize":"480px 304px","bgRepeat":"no-repeat"}
,
"button20480":{"x":198,"y":694,"w":83.000000,"h":27.000000,"stylemods":[{"sel":"div.button20480Text","decl":" { position:fixed; left:2px; top:2px; width:78px; height:22px;}"},{"sel":"span.button20480Text","decl":" { display:table-cell; position:relative; width:78px; height:22px; vertical-align:middle; text-align:center; line-height:5px; font-size:5px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFMAAAAbCAYAAAAAubMBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVGhD7cEBDQAAAMKg909tDwcEAAAAAAAAAACvaiMfAAGviE5dAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFMAAAAbCAYAAAAAubMBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVGhD7cEBDQAAAMKg909tDwcEAAAAAAAAAACvaiMfAAGviE5dAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFMAAAAbCAYAAAAAubMBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVGhD7cEBDQAAAMKg909tDwcEAAAAAAAAAACvaiMfAAGviE5dAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFMAAAAbCAYAAAAAubMBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVGhD7cEBDQAAAMKg909tDwcEAAAAAAAAAACvaiMfAAGviE5dAAAAAElFTkSuQmCC"  ,"fd": "images/tombol.png" ,"fdO": "images/tombol.png" ,"fdD": "images/tombol.png" ,"fdDi": "images/tombol.png" ,"p": "M 0.000000 0.000000 L 82.000000 0.000000 L 82.000000 26.000000 L 0.000000 26.000000 L 0.000000 0.000000 z"}
,
"text21064":{"x":53,"y":75,"w":373,"h":88,"txtscale":100,"bOffBottom":0}
,
"entry21065":{"x":53,"y":126,"w":407,"h":25,"fsize":39,"bOffBottom":0}
,
"text21011":{"x":53,"y":75,"w":373,"h":88,"txtscale":100,"bOffBottom":0}
,
"entry21012":{"x":53,"y":163,"w":407,"h":25,"fsize":39,"bOffBottom":0}
,
"text21037":{"x":53,"y":75,"w":373,"h":44,"txtscale":100,"bOffBottom":0}
,
"entry21038":{"x":53,"y":126,"w":407,"h":25,"fsize":39,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/login_bg_1_.png']
}}
