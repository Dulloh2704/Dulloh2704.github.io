DesktopResponsive={"1009":{
"pageLayer":{"w":1265,"h":800,"bgColor":"#ffffff","bgImage":"images/start_bg.png","bgSize":"1265px 800px","bgRepeat":"no-repeat"}
,
"button2124":{"x":270,"y":452,"w":290.000000,"h":82.000000,"stylemods":[{"sel":"div.button2124Text","decl":" { position:fixed; left:2px; top:2px; width:285px; height:77px;}"},{"sel":"span.button2124Text","decl":" { display:table-cell; position:relative; width:285px; height:77px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASIAAABSCAYAAADw69nDAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABySURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOdqc/EAAQ8dtaoAAAAASUVORK5CYII=" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASIAAABSCAYAAADw69nDAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABySURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOdqc/EAAQ8dtaoAAAAASUVORK5CYII=" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASIAAABSCAYAAADw69nDAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABySURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOdqc/EAAQ8dtaoAAAAASUVORK5CYII=" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASIAAABSCAYAAADw69nDAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABySURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOdqc/EAAQ8dtaoAAAAASUVORK5CYII="  ,"fd": "images/start.png" ,"fdO": "images/start.png" ,"fdD": "images/start.png" ,"fdDi": "images/start.png" ,"p": "M 0.000000 0.000000 L 289.000000 0.000000 L 289.000000 81.000000 L 0.000000 81.000000 L 0.000000 0.000000 z","i":"images/button2124.png","irol":"images/button2124_over.png","ion":"images/button2124_down.png","idis":"images/button2124_disabled.png"}
,
"image35949":{"x":0,"y":-6,"w":1265,"h":800,"bOffBottom":0,"i":"images/halaman_start.png"}
,
"text21091":{"x":420,"y":251,"w":150,"h":44,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/start.png','images/start_bg.png','images/halaman_start.png','images/button2124.png','images/button2124_over.png','images/button2124_down.png','images/button2124_disabled.png']
}}
