DesktopResponsive={"1009":{
"pageLayer":{"w":1265,"h":800,"bgColor":"#ffffff","bgImage":"images/20240526_195725_0000.png","bgSize":"1265px 800px","bgRepeat":"no-repeat"}
,
"button43204":{"x":1175,"y":19,"w":71.000000,"h":71.000000,"stylemods":[{"sel":"div.button43204Text","decl":" { position:fixed; left:2px; top:2px; width:66px; height:66px;}"},{"sel":"span.button43204Text","decl":" { display:table-cell; position:relative; width:66px; height:66px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEcAAABHCAYAAABVsFofAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAArSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAHiqAU8LAAEPRNRsAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEcAAABHCAYAAABVsFofAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAArSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAHiqAU8LAAEPRNRsAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEcAAABHCAYAAABVsFofAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAArSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAHiqAU8LAAEPRNRsAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEcAAABHCAYAAABVsFofAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAArSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAHiqAU8LAAEPRNRsAAAAAElFTkSuQmCC"  ,"fd": "images/tombol_home.png" ,"fdO": "images/tombol_home.png" ,"fdD": "images/tombol_home.png" ,"fdDi": "images/tombol_home.png" ,"p": "M 0.000000 0.000000 L 70.000000 0.000000 L 70.000000 70.000000 L 0.000000 70.000000 L 0.000000 0.000000 z","i":"images/button43204.png","irol":"images/button43204_over.png","ion":"images/button43204_down.png","idis":"images/button43204_disabled.png"}
,
"button29597":{"x":1070,"y":656,"w":90.000000,"h":90.000000,"stylemods":[{"sel":"div.button29597Text","decl":" { position:fixed; left:2px; top:2px; width:85px; height:85px;}"},{"sel":"span.button29597Text","decl":" { display:table-cell; position:relative; width:85px; height:85px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA2SURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXKkBfuoAAfOj6jAAAAAASUVORK5CYII=" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA2SURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXKkBfuoAAfOj6jAAAAAASUVORK5CYII=" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA2SURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXKkBfuoAAfOj6jAAAAAASUVORK5CYII=" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA2SURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXKkBfuoAAfOj6jAAAAAASUVORK5CYII="  ,"fd": "images/tombol_next.png" ,"fdO": "images/tombol_next.png" ,"fdD": "images/tombol_next.png" ,"fdDi": "images/tombol_next.png" ,"p": "M 0.000000 0.000000 L 89.000000 0.000000 L 89.000000 89.000000 L 0.000000 89.000000 L 0.000000 0.000000 z","i":"images/button29597.png","irol":"images/button29597_over.png","ion":"images/button29597_down.png","idis":"images/button29597_disabled.png"}
,
"other28047":{"x":1026,"y":54,"w":138,"h":70,"fsize":24,"bOffBottom":0}
,
"text20030":{"x":-46,"y":208,"w":23,"h":37,"txtscale":100,"bOffBottom":0}
,
"image20031":{"x":-36,"y":253,"w":19,"h":9,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20033":{"x":568,"y":523,"fsize":39,"bOffBottom":0}
,
"image20034":{"x":-36,"y":270,"w":19,"h":9,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20036":{"x":569,"y":550,"fsize":39,"bOffBottom":0}
,
"image20037":{"x":-36,"y":287,"w":19,"h":9,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20039":{"x":569,"y":583,"fsize":39,"bOffBottom":0}
,
"image20040":{"x":-36,"y":304,"w":19,"h":9,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20042":{"x":569,"y":612,"fsize":39,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/tombol_home.png','images/tombol_next.png','images/20240526_195725_0000.png','images/button43204.png','images/button43204_over.png','images/button43204_down.png','images/button43204_disabled.png','images/button29597.png','images/button29597_over.png','images/button29597_down.png','images/button29597_disabled.png']
}}
