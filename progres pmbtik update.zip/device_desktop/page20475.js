DesktopResponsive={"1009":{
"pageLayer":{"w":1265,"h":800,"bgColor":"#ffffff","bgImage":"images/login_bg_1_.png","bgSize":"1265px 800px","bgRepeat":"no-repeat"}
,
"button20480":{"x":522,"y":694,"w":218.000000,"h":70.000000,"stylemods":[{"sel":"div.button20480Text","decl":" { position:fixed; left:2px; top:2px; width:213px; height:65px;}"},{"sel":"span.button20480Text","decl":" { display:table-cell; position:relative; width:213px; height:65px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANoAAABGCAYAAACquYrjAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABSSURBVHhe7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHCsBu62AAGCSukvAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANoAAABGCAYAAACquYrjAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABSSURBVHhe7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHCsBu62AAGCSukvAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANoAAABGCAYAAACquYrjAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABSSURBVHhe7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHCsBu62AAGCSukvAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANoAAABGCAYAAACquYrjAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABSSURBVHhe7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHCsBu62AAGCSukvAAAAAElFTkSuQmCC"  ,"fd": "images/tombol.png" ,"fdO": "images/tombol.png" ,"fdD": "images/tombol.png" ,"fdDi": "images/tombol.png" ,"p": "M 0.000000 0.000000 L 217.000000 0.000000 L 217.000000 69.000000 L 0.000000 69.000000 L 0.000000 0.000000 z","i":"images/button20480.png","irol":"images/button20480_over.png","ion":"images/button20480_down.png","idis":"images/button20480_disabled.png"}
,
"text21064":{"x":-64,"y":211,"w":38,"h":90,"txtscale":100,"bOffBottom":0}
,
"entry21065":{"x":280,"y":591,"w":450,"h":41,"fsize":39,"bOffBottom":0}
,
"text21011":{"x":-62,"y":217,"w":26,"h":88,"txtscale":100,"bOffBottom":0}
,
"entry21012":{"x":417,"y":437,"w":450,"h":45,"fsize":39,"bOffBottom":0}
,
"text21037":{"x":-55,"y":218,"w":24,"h":44,"txtscale":100,"bOffBottom":0}
,
"entry21038":{"x":446,"y":513,"w":450,"h":43,"fsize":39,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/tombol.png','images/login_bg_1_.png','images/button20480.png','images/button20480_over.png','images/button20480_down.png','images/button20480_disabled.png']
}}
