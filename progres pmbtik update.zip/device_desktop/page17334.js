DesktopResponsive={"1009":{
"pageLayer":{"w":1265,"h":800,"bgColor":"#ffffff","bgImage":"images/eval1_1_.png","bgSize":"1265px 800px","bgRepeat":"no-repeat"}
,
"button42847":{"x":1175,"y":19,"w":71.000000,"h":71.000000,"stylemods":[{"sel":"div.button42847Text","decl":" { position:fixed; left:2px; top:2px; width:66px; height:66px;}"},{"sel":"span.button42847Text","decl":" { display:table-cell; position:relative; width:66px; height:66px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEcAAABHCAYAAABVsFofAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAArSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAHiqAU8LAAEPRNRsAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEcAAABHCAYAAABVsFofAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAArSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAHiqAU8LAAEPRNRsAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEcAAABHCAYAAABVsFofAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAArSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAHiqAU8LAAEPRNRsAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEcAAABHCAYAAABVsFofAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAArSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAHiqAU8LAAEPRNRsAAAAAElFTkSuQmCC"  ,"fd": "images/tombol_home.png" ,"fdO": "images/tombol_home.png" ,"fdD": "images/tombol_home.png" ,"fdDi": "images/tombol_home.png" ,"p": "M 0.000000 0.000000 L 70.000000 0.000000 L 70.000000 70.000000 L 0.000000 70.000000 L 0.000000 0.000000 z","i":"images/button42847.png","irol":"images/button42847_over.png","ion":"images/button42847_down.png","idis":"images/button42847_disabled.png"}
,
"button28643":{"x":1070,"y":656,"w":90.000000,"h":90.000000,"stylemods":[{"sel":"div.button28643Text","decl":" { position:fixed; left:2px; top:2px; width:85px; height:85px;}"},{"sel":"span.button28643Text","decl":" { display:table-cell; position:relative; width:85px; height:85px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA2SURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXKkBfuoAAfOj6jAAAAAASUVORK5CYII=" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA2SURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXKkBfuoAAfOj6jAAAAAASUVORK5CYII=" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA2SURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXKkBfuoAAfOj6jAAAAAASUVORK5CYII=" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA2SURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXKkBfuoAAfOj6jAAAAAASUVORK5CYII="  ,"fd": "images/tombol_next.png" ,"fdO": "images/tombol_next.png" ,"fdD": "images/tombol_next.png" ,"fdDi": "images/tombol_next.png" ,"p": "M 0.000000 0.000000 L 89.000000 0.000000 L 89.000000 89.000000 L 0.000000 89.000000 L 0.000000 0.000000 z","i":"images/button28643.png","irol":"images/button28643_over.png","ion":"images/button28643_down.png","idis":"images/button28643_disabled.png"}
,
"other27973":{"x":1026,"y":54,"w":138,"h":70,"fsize":24,"bOffBottom":0}
,
"text19021":{"x":-53,"y":234,"w":23,"h":37,"txtscale":100,"bOffBottom":0}
,
"text19022":{"x":167,"y":245,"w":479,"h":37,"txtscale":100,"bOffBottom":0}
,
"image19023":{"x":-45,"y":300,"w":19,"h":9,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio19025":{"x":548,"y":344,"fsize":39,"bOffBottom":0}
,
"image19026":{"x":-45,"y":330,"w":19,"h":9,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio19028":{"x":547,"y":375,"fsize":39,"bOffBottom":0}
,
"image19029":{"x":-45,"y":347,"w":19,"h":9,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio19031":{"x":548,"y":412,"fsize":39,"bOffBottom":0}
,
"image19032":{"x":-45,"y":364,"w":19,"h":9,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio19034":{"x":548,"y":444,"fsize":39,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/tombol_home.png','images/tombol_next.png','images/eval1_1_.png','images/button42847.png','images/button42847_over.png','images/button42847_down.png','images/button42847_disabled.png','images/button28643.png','images/button28643_over.png','images/button28643_down.png','images/button28643_disabled.png']
}}
