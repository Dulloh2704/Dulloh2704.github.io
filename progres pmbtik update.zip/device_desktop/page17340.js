DesktopResponsive={"1009":{
"pageLayer":{"w":1265,"h":800,"bgColor":"#ffffff","bgImage":"images/eval7.png","bgSize":"1265px 800px","bgRepeat":"no-repeat"}
,
"button43153":{"x":1175,"y":19,"w":71.000000,"h":71.000000,"stylemods":[{"sel":"div.button43153Text","decl":" { position:fixed; left:2px; top:2px; width:66px; height:66px;}"},{"sel":"span.button43153Text","decl":" { display:table-cell; position:relative; width:66px; height:66px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEcAAABHCAYAAABVsFofAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAArSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAHiqAU8LAAEPRNRsAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEcAAABHCAYAAABVsFofAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAArSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAHiqAU8LAAEPRNRsAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEcAAABHCAYAAABVsFofAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAArSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAHiqAU8LAAEPRNRsAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEcAAABHCAYAAABVsFofAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAArSURBVHhe7cExAQAAAMKg9U9tCy8gAAAAAAAAAAAAAAAAAAAAAAAAAHiqAU8LAAEPRNRsAAAAAElFTkSuQmCC"  ,"fd": "images/tombol_home.png" ,"fdO": "images/tombol_home.png" ,"fdD": "images/tombol_home.png" ,"fdDi": "images/tombol_home.png" ,"p": "M 0.000000 0.000000 L 70.000000 0.000000 L 70.000000 70.000000 L 0.000000 70.000000 L 0.000000 0.000000 z","i":"images/button43153.png","irol":"images/button43153_over.png","ion":"images/button43153_down.png","idis":"images/button43153_disabled.png"}
,
"button29545":{"x":1070,"y":656,"w":90.000000,"h":90.000000,"stylemods":[{"sel":"div.button29545Text","decl":" { position:fixed; left:2px; top:2px; width:85px; height:85px;}"},{"sel":"span.button29545Text","decl":" { display:table-cell; position:relative; width:85px; height:85px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA2SURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXKkBfuoAAfOj6jAAAAAASUVORK5CYII=" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA2SURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXKkBfuoAAfOj6jAAAAAASUVORK5CYII=" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA2SURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXKkBfuoAAfOj6jAAAAAASUVORK5CYII=" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA2SURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXKkBfuoAAfOj6jAAAAAASUVORK5CYII="  ,"fd": "images/tombol_next.png" ,"fdO": "images/tombol_next.png" ,"fdD": "images/tombol_next.png" ,"fdDi": "images/tombol_next.png" ,"p": "M 0.000000 0.000000 L 89.000000 0.000000 L 89.000000 89.000000 L 0.000000 89.000000 L 0.000000 0.000000 z","i":"images/button29545.png","irol":"images/button29545_over.png","ion":"images/button29545_down.png","idis":"images/button29545_disabled.png"}
,
"other28041":{"x":1026,"y":54,"w":138,"h":70,"fsize":24,"bOffBottom":0}
,
"text19817":{"x":-44,"y":200,"w":29,"h":37,"txtscale":100,"bOffBottom":0}
,
"image19818":{"x":-50,"y":257,"w":19,"h":9,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio19820":{"x":546,"y":521,"fsize":39,"bOffBottom":0}
,
"image19821":{"x":-50,"y":274,"w":19,"h":9,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio19823":{"x":546,"y":552,"fsize":39,"bOffBottom":0}
,
"image19824":{"x":-50,"y":291,"w":19,"h":9,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio19826":{"x":546,"y":587,"fsize":39,"bOffBottom":0}
,
"image19827":{"x":-50,"y":308,"w":19,"h":9,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio19829":{"x":546,"y":620,"fsize":39,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/tombol_home.png','images/tombol_next.png','images/eval7.png','images/button43153.png','images/button43153_over.png','images/button43153_down.png','images/button43153_disabled.png','images/button29545.png','images/button29545_over.png','images/button29545_down.png','images/button29545_disabled.png']
}}
