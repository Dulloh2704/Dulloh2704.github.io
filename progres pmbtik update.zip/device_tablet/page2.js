TabletResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff","bgImage":"images/start_bg.png","bgSize":"1009px 638px","bgRepeat":"no-repeat"}
,
"button2124":{"x":215,"y":361,"w":232.000000,"h":66.000000,"stylemods":[{"sel":"div.button2124Text","decl":" { position:fixed; left:2px; top:2px; width:227px; height:61px;}"},{"sel":"span.button2124Text","decl":" { display:table-cell; position:relative; width:227px; height:61px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOgAAABCCAYAAABdLprwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABTSURBVHhe7cEBDQAAAMKg909tDjcgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAu1ADvggAB6FApFwAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOgAAABCCAYAAABdLprwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABTSURBVHhe7cEBDQAAAMKg909tDjcgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAu1ADvggAB6FApFwAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOgAAABCCAYAAABdLprwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABTSURBVHhe7cEBDQAAAMKg909tDjcgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAu1ADvggAB6FApFwAAAABJRU5ErkJggg==" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOgAAABCCAYAAABdLprwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABTSURBVHhe7cEBDQAAAMKg909tDjcgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAu1ADvggAB6FApFwAAAABJRU5ErkJggg=="  ,"fd": "images/start.png" ,"fdO": "images/start.png" ,"fdD": "images/start.png" ,"fdDi": "images/start.png" ,"p": "M 0.000000 0.000000 L 231.000000 0.000000 L 231.000000 65.000000 L 0.000000 65.000000 L 0.000000 0.000000 z"}
,
"image35949":{"x":0,"y":-4,"w":1009,"h":638,"bOffBottom":0,"i":"images/halaman_start.png"}
,
"text21091":{"x":335,"y":200,"w":120,"h":44,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/start_bg.png']
},
"785":{
"pageLayer":{"w":785,"h":1000,"bgColor":"#ffffff","bgImage":"images/start_bg.png","bgSize":"785px 496px","bgRepeat":"no-repeat"}
,
"button2124":{"x":168,"y":452,"w":180.000000,"h":51.000000,"stylemods":[{"sel":"div.button2124Text","decl":" { position:fixed; left:2px; top:2px; width:175px; height:46px;}"},{"sel":"span.button2124Text","decl":" { display:table-cell; position:relative; width:175px; height:46px; vertical-align:middle; text-align:center; line-height:9px; font-size:9px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAAzCAYAAAA+eCJSAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA7SURBVHhe7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4UAOPowABXdpdowAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAAzCAYAAAA+eCJSAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA7SURBVHhe7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4UAOPowABXdpdowAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAAzCAYAAAA+eCJSAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA7SURBVHhe7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4UAOPowABXdpdowAAAABJRU5ErkJggg==" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALQAAAAzCAYAAAA+eCJSAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA7SURBVHhe7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4UAOPowABXdpdowAAAABJRU5ErkJggg=="  ,"fd": "images/start.png" ,"fdO": "images/start.png" ,"fdD": "images/start.png" ,"fdDi": "images/start.png" ,"p": "M 0.000000 0.000000 L 179.000000 0.000000 L 179.000000 50.000000 L 0.000000 50.000000 L 0.000000 0.000000 z"}
,
"image35949":{"x":0,"y":-5,"w":785,"h":496,"bOffBottom":0,"i":"images/halaman_start.png"}
,
"text21091":{"x":261,"y":251,"w":93,"h":44,"txtscale":100,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/start_bg.png']
}}
