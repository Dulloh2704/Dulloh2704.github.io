TabletResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff","bgImage":"images/pmbtik_1265_x_800_20240518_100911_0000.png","bgSize":"1009px 638px","bgRepeat":"no-repeat"}
,
"button43306":{"x":937,"y":15,"w":57.000000,"h":57.000000,"stylemods":[{"sel":"div.button43306Text","decl":" { position:fixed; left:2px; top:2px; width:52px; height:52px;}"},{"sel":"span.button43306Text","decl":" { display:table-cell; position:relative; width:52px; height:52px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADkAAAA5CAYAAACMGIOFAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAkSURBVGhD7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAA+FQDMv0AAXmhAroAAAAASUVORK5CYII=" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADkAAAA5CAYAAACMGIOFAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAkSURBVGhD7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAA+FQDMv0AAXmhAroAAAAASUVORK5CYII=" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADkAAAA5CAYAAACMGIOFAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAkSURBVGhD7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAA+FQDMv0AAXmhAroAAAAASUVORK5CYII=" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADkAAAA5CAYAAACMGIOFAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAkSURBVGhD7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAA+FQDMv0AAXmhAroAAAAASUVORK5CYII="  ,"fd": "images/tombol_home.png" ,"fdO": "images/tombol_home.png" ,"fdD": "images/tombol_home.png" ,"fdDi": "images/tombol_home.png" ,"p": "M 0.000000 0.000000 L 56.000000 0.000000 L 56.000000 56.000000 L 0.000000 56.000000 L 0.000000 0.000000 z"}
,
"button32055":{"x":665,"y":484,"w":253.000000,"h":161.000000,"stylemods":[{"sel":"div.button32055Text","decl":" { position:fixed; left:2px; top:2px; width:248px; height:156px;}"},{"sel":"span.button32055Text","decl":" { display:table-cell; position:relative; width:248px; height:156px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAP0AAAChCAYAAAAMeblwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAC1SURBVHhe7cGBAAAAAMOg+VMf4QJVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABfDX0zAAHdIh/8AAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAP0AAAChCAYAAAAMeblwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAC1SURBVHhe7cGBAAAAAMOg+VMf4QJVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABfDX0zAAHdIh/8AAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAP0AAAChCAYAAAAMeblwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAC1SURBVHhe7cGBAAAAAMOg+VMf4QJVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABfDX0zAAHdIh/8AAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAP0AAAChCAYAAAAMeblwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAC1SURBVHhe7cGBAAAAAMOg+VMf4QJVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABfDX0zAAHdIh/8AAAAAElFTkSuQmCC"  ,"fd": "images/pmbtik_1265_x_800_20240518_100816_0000.png" ,"fdO": "images/pmbtik_1265_x_800_20240518_100816_0000.png" ,"fdD": "images/pmbtik_1265_x_800_20240518_100816_0000.png" ,"fdDi": "images/pmbtik_1265_x_800_20240518_100816_0000.png" ,"p": "M 0.000000 0.000000 L 252.000000 0.000000 L 252.000000 160.000000 L 0.000000 160.000000 L 0.000000 0.000000 z"}
,
"other28059":{"x":818,"y":43,"w":138,"h":70,"fsize":24,"bOffBottom":0}
,
"text20312":{"x":-35,"y":153,"w":30,"h":30,"txtscale":100,"bOffBottom":0}
,
"image20313":{"x":-20,"y":191,"w":15,"h":7,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20315":{"x":444,"y":273,"fsize":39,"bOffBottom":0}
,
"image20316":{"x":-20,"y":205,"w":15,"h":7,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20318":{"x":444,"y":297,"fsize":39,"bOffBottom":0}
,
"image20319":{"x":-20,"y":219,"w":15,"h":7,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20321":{"x":444,"y":322,"fsize":39,"bOffBottom":0}
,
"image20322":{"x":-20,"y":232,"w":15,"h":7,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20324":{"x":444,"y":344,"fsize":39,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/pmbtik_1265_x_800_20240518_100911_0000.png']
},
"785":{
"pageLayer":{"w":785,"h":1000,"bgColor":"#ffffff","bgImage":"images/pmbtik_1265_x_800_20240518_100911_0000.png","bgSize":"785px 496px","bgRepeat":"no-repeat"}
,
"button43306":{"x":729,"y":19,"w":44.000000,"h":44.000000,"stylemods":[{"sel":"div.button43306Text","decl":" { position:fixed; left:2px; top:2px; width:39px; height:39px;}"},{"sel":"span.button43306Text","decl":" { display:table-cell; position:relative; width:39px; height:39px; vertical-align:middle; text-align:center; line-height:9px; font-size:9px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAAAAALjUAB5sAAHaZvU3AAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAAAAALjUAB5sAAHaZvU3AAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAAAAALjUAB5sAAHaZvU3AAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAAAAALjUAB5sAAHaZvU3AAAAAElFTkSuQmCC"  ,"fd": "images/tombol_home.png" ,"fdO": "images/tombol_home.png" ,"fdD": "images/tombol_home.png" ,"fdDi": "images/tombol_home.png" ,"p": "M 0.000000 0.000000 L 43.000000 0.000000 L 43.000000 43.000000 L 0.000000 43.000000 L 0.000000 0.000000 z"}
,
"button32055":{"x":518,"y":607,"w":197.000000,"h":125.000000,"stylemods":[{"sel":"div.button32055Text","decl":" { position:fixed; left:2px; top:2px; width:192px; height:120px;}"},{"sel":"span.button32055Text","decl":" { display:table-cell; position:relative; width:192px; height:120px; vertical-align:middle; text-align:center; line-height:9px; font-size:9px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMUAAAB9CAYAAAASoafoAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAB3SURBVHhe7cExAQAAAMKg9U9tCF8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD41QCBUAABP9djRQAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMUAAAB9CAYAAAASoafoAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAB3SURBVHhe7cExAQAAAMKg9U9tCF8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD41QCBUAABP9djRQAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMUAAAB9CAYAAAASoafoAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAB3SURBVHhe7cExAQAAAMKg9U9tCF8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD41QCBUAABP9djRQAAAABJRU5ErkJggg==" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMUAAAB9CAYAAAASoafoAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAB3SURBVHhe7cExAQAAAMKg9U9tCF8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD41QCBUAABP9djRQAAAABJRU5ErkJggg=="  ,"fd": "images/pmbtik_1265_x_800_20240518_100816_0000.png" ,"fdO": "images/pmbtik_1265_x_800_20240518_100816_0000.png" ,"fdD": "images/pmbtik_1265_x_800_20240518_100816_0000.png" ,"fdDi": "images/pmbtik_1265_x_800_20240518_100816_0000.png" ,"p": "M 0.000000 0.000000 L 196.000000 0.000000 L 196.000000 124.000000 L 0.000000 124.000000 L 0.000000 0.000000 z"}
,
"other28059":{"x":637,"y":54,"w":138,"h":70,"fsize":24,"bOffBottom":0}
,
"text20312":{"x":-28,"y":192,"w":23,"h":23,"txtscale":100,"bOffBottom":0}
,
"image20313":{"x":-17,"y":240,"w":12,"h":6,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20315":{"x":345,"y":343,"fsize":39,"bOffBottom":0}
,
"image20316":{"x":-17,"y":257,"w":12,"h":6,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20318":{"x":345,"y":372,"fsize":39,"bOffBottom":0}
,
"image20319":{"x":-17,"y":274,"w":12,"h":6,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20321":{"x":345,"y":404,"fsize":39,"bOffBottom":0}
,
"image20322":{"x":-17,"y":291,"w":12,"h":6,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20324":{"x":345,"y":432,"fsize":39,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/pmbtik_1265_x_800_20240518_100911_0000.png']
}}
