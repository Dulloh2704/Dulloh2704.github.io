TabletResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff","bgImage":"images/login_bg_1_.png","bgSize":"1009px 638px","bgRepeat":"no-repeat"}
,
"button20480":{"x":416,"y":554,"w":174.000000,"h":56.000000,"stylemods":[{"sel":"div.button20480Text","decl":" { position:fixed; left:2px; top:2px; width:169px; height:51px;}"},{"sel":"span.button20480Text","decl":" { display:table-cell; position:relative; width:169px; height:51px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAK4AAAA4CAYAAABkM8OwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA9SURBVHhe7cExAQAAAMKg9U9tCU8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOCkBph4AAEqM00QAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAK4AAAA4CAYAAABkM8OwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA9SURBVHhe7cExAQAAAMKg9U9tCU8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOCkBph4AAEqM00QAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAK4AAAA4CAYAAABkM8OwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA9SURBVHhe7cExAQAAAMKg9U9tCU8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOCkBph4AAEqM00QAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAK4AAAA4CAYAAABkM8OwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA9SURBVHhe7cExAQAAAMKg9U9tCU8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOCkBph4AAEqM00QAAAAAElFTkSuQmCC"  ,"fd": "images/tombol.png" ,"fdO": "images/tombol.png" ,"fdD": "images/tombol.png" ,"fdDi": "images/tombol.png" ,"p": "M 0.000000 0.000000 L 173.000000 0.000000 L 173.000000 55.000000 L 0.000000 55.000000 L 0.000000 0.000000 z"}
,
"text21064":{"x":-35,"y":168,"w":30,"h":88,"txtscale":100,"bOffBottom":0}
,
"entry21065":{"x":223,"y":471,"w":450,"h":41,"fsize":39,"bOffBottom":0}
,
"text21011":{"x":-26,"y":173,"w":21,"h":88,"txtscale":100,"bOffBottom":0}
,
"entry21012":{"x":333,"y":348,"w":450,"h":45,"fsize":39,"bOffBottom":0}
,
"text21037":{"x":-24,"y":174,"w":19,"h":44,"txtscale":100,"bOffBottom":0}
,
"entry21038":{"x":356,"y":409,"w":450,"h":43,"fsize":39,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/login_bg_1_.png']
},
"785":{
"pageLayer":{"w":785,"h":1000,"bgColor":"#ffffff","bgImage":"images/login_bg_1_.png","bgSize":"785px 496px","bgRepeat":"no-repeat"}
,
"button20480":{"x":324,"y":694,"w":136.000000,"h":44.000000,"stylemods":[{"sel":"div.button20480Text","decl":" { position:fixed; left:2px; top:2px; width:131px; height:39px;}"},{"sel":"span.button20480Text","decl":" { display:table-cell; position:relative; width:131px; height:39px; vertical-align:middle; text-align:center; line-height:9px; font-size:9px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIgAAAAsCAYAAAC+N/CqAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAtSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHdqXawAAcKBqVAAAAAASUVORK5CYII=" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIgAAAAsCAYAAAC+N/CqAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAtSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHdqXawAAcKBqVAAAAAASUVORK5CYII=" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIgAAAAsCAYAAAC+N/CqAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAtSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHdqXawAAcKBqVAAAAAASUVORK5CYII=" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIgAAAAsCAYAAAC+N/CqAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAtSURBVHhe7cEBAQAAAIIg/69uSEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHdqXawAAcKBqVAAAAAASUVORK5CYII="  ,"fd": "images/tombol.png" ,"fdO": "images/tombol.png" ,"fdD": "images/tombol.png" ,"fdDi": "images/tombol.png" ,"p": "M 0.000000 0.000000 L 135.000000 0.000000 L 135.000000 43.000000 L 0.000000 43.000000 L 0.000000 0.000000 z"}
,
"text21064":{"x":-29,"y":211,"w":24,"h":88,"txtscale":100,"bOffBottom":0}
,
"entry21065":{"x":174,"y":591,"w":450,"h":41,"fsize":39,"bOffBottom":0}
,
"text21011":{"x":-21,"y":217,"w":16,"h":88,"txtscale":100,"bOffBottom":0}
,
"entry21012":{"x":259,"y":437,"w":450,"h":45,"fsize":39,"bOffBottom":0}
,
"text21037":{"x":-20,"y":218,"w":15,"h":44,"txtscale":100,"bOffBottom":0}
,
"entry21038":{"x":277,"y":513,"w":450,"h":43,"fsize":39,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/login_bg_1_.png']
}}
