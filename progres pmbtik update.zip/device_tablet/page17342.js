TabletResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff","bgImage":"images/eval9.png","bgSize":"1009px 638px","bgRepeat":"no-repeat"}
,
"button43255":{"x":937,"y":15,"w":57.000000,"h":57.000000,"stylemods":[{"sel":"div.button43255Text","decl":" { position:fixed; left:2px; top:2px; width:52px; height:52px;}"},{"sel":"span.button43255Text","decl":" { display:table-cell; position:relative; width:52px; height:52px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADkAAAA5CAYAAACMGIOFAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAkSURBVGhD7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAA+FQDMv0AAXmhAroAAAAASUVORK5CYII=" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADkAAAA5CAYAAACMGIOFAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAkSURBVGhD7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAA+FQDMv0AAXmhAroAAAAASUVORK5CYII=" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADkAAAA5CAYAAACMGIOFAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAkSURBVGhD7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAA+FQDMv0AAXmhAroAAAAASUVORK5CYII=" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADkAAAA5CAYAAACMGIOFAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAkSURBVGhD7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAA+FQDMv0AAXmhAroAAAAASUVORK5CYII="  ,"fd": "images/tombol_home.png" ,"fdO": "images/tombol_home.png" ,"fdD": "images/tombol_home.png" ,"fdDi": "images/tombol_home.png" ,"p": "M 0.000000 0.000000 L 56.000000 0.000000 L 56.000000 56.000000 L 0.000000 56.000000 L 0.000000 0.000000 z"}
,
"button29649":{"x":853,"y":523,"w":72.000000,"h":72.000000,"stylemods":[{"sel":"div.button29649Text","decl":" { position:fixed; left:2px; top:2px; width:67px; height:67px;}"},{"sel":"span.button29649Text","decl":" { display:table-cell; position:relative; width:67px; height:67px; vertical-align:middle; text-align:center; line-height:12px; font-size:12px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAArSURBVHhe7cEBDQAAAMKg909tDjcgAAAAAAAAAAAAAAAAAAAAAAAAAIALNVFIAAG+eBbVAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAArSURBVHhe7cEBDQAAAMKg909tDjcgAAAAAAAAAAAAAAAAAAAAAAAAAIALNVFIAAG+eBbVAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAArSURBVHhe7cEBDQAAAMKg909tDjcgAAAAAAAAAAAAAAAAAAAAAAAAAIALNVFIAAG+eBbVAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAArSURBVHhe7cEBDQAAAMKg909tDjcgAAAAAAAAAAAAAAAAAAAAAAAAAIALNVFIAAG+eBbVAAAAAElFTkSuQmCC"  ,"fd": "images/tombol_next.png" ,"fdO": "images/tombol_next.png" ,"fdD": "images/tombol_next.png" ,"fdDi": "images/tombol_next.png" ,"p": "M 0.000000 0.000000 L 71.000000 0.000000 L 71.000000 71.000000 L 0.000000 71.000000 L 0.000000 0.000000 z"}
,
"other28053":{"x":818,"y":43,"w":138,"h":70,"fsize":24,"bOffBottom":0}
,
"text20172":{"x":-19,"y":152,"w":14,"h":30,"txtscale":100,"bOffBottom":0}
,
"image20173":{"x":-20,"y":194,"w":15,"h":7,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20175":{"x":440,"y":385,"fsize":39,"bOffBottom":0}
,
"image20176":{"x":-20,"y":207,"w":15,"h":7,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20178":{"x":440,"y":407,"fsize":39,"bOffBottom":0}
,
"image20179":{"x":-20,"y":221,"w":15,"h":7,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20181":{"x":440,"y":435,"fsize":39,"bOffBottom":0}
,
"image20182":{"x":-20,"y":235,"w":15,"h":7,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20184":{"x":440,"y":459,"fsize":39,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/eval9.png']
},
"785":{
"pageLayer":{"w":785,"h":1000,"bgColor":"#ffffff","bgImage":"images/eval9.png","bgSize":"785px 496px","bgRepeat":"no-repeat"}
,
"button43255":{"x":729,"y":19,"w":44.000000,"h":44.000000,"stylemods":[{"sel":"div.button43255Text","decl":" { position:fixed; left:2px; top:2px; width:39px; height:39px;}"},{"sel":"span.button43255Text","decl":" { display:table-cell; position:relative; width:39px; height:39px; vertical-align:middle; text-align:center; line-height:9px; font-size:9px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAAAAALjUAB5sAAHaZvU3AAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAAAAALjUAB5sAAHaZvU3AAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAAAAALjUAB5sAAHaZvU3AAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVFhH7cExAQAAAMKg9U9tBn8gAAAAAAAAALjUAB5sAAHaZvU3AAAAAElFTkSuQmCC"  ,"fd": "images/tombol_home.png" ,"fdO": "images/tombol_home.png" ,"fdD": "images/tombol_home.png" ,"fdDi": "images/tombol_home.png" ,"p": "M 0.000000 0.000000 L 43.000000 0.000000 L 43.000000 43.000000 L 0.000000 43.000000 L 0.000000 0.000000 z"}
,
"button29649":{"x":664,"y":656,"w":56.000000,"h":56.000000,"stylemods":[{"sel":"div.button29649Text","decl":" { position:fixed; left:2px; top:2px; width:51px; height:51px;}"},{"sel":"span.button29649Text","decl":" { display:table-cell; position:relative; width:51px; height:51px; vertical-align:middle; text-align:center; line-height:9px; font-size:9px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAjSURBVGhD7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAABwqQYxOAAB1daAAAAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAjSURBVGhD7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAABwqQYxOAAB1daAAAAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAjSURBVGhD7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAABwqQYxOAAB1daAAAAAAABJRU5ErkJggg==" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAjSURBVGhD7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAABwqQYxOAAB1daAAAAAAABJRU5ErkJggg=="  ,"fd": "images/tombol_next.png" ,"fdO": "images/tombol_next.png" ,"fdD": "images/tombol_next.png" ,"fdDi": "images/tombol_next.png" ,"p": "M 0.000000 0.000000 L 55.000000 0.000000 L 55.000000 55.000000 L 0.000000 55.000000 L 0.000000 0.000000 z"}
,
"other28053":{"x":637,"y":54,"w":138,"h":70,"fsize":24,"bOffBottom":0}
,
"text20172":{"x":-16,"y":190,"w":11,"h":23,"txtscale":100,"bOffBottom":0}
,
"image20173":{"x":-17,"y":243,"w":12,"h":6,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20175":{"x":342,"y":483,"fsize":39,"bOffBottom":0}
,
"image20176":{"x":-17,"y":260,"w":12,"h":6,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20178":{"x":342,"y":511,"fsize":39,"bOffBottom":0}
,
"image20179":{"x":-17,"y":277,"w":12,"h":6,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20181":{"x":342,"y":546,"fsize":39,"bOffBottom":0}
,
"image20182":{"x":-17,"y":294,"w":12,"h":6,"bOffBottom":0,"i":"images/save_20240510_205136.png"}
,
"radio20184":{"x":342,"y":576,"fsize":39,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/eval9.png']
}}
